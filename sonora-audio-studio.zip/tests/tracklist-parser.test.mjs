import test from 'node:test';
import assert from 'node:assert/strict';
import { parseUserTrackList, parseUserTimecode } from '../src/tracklist-parser.js';

const newList = `00:00:45 我爱你
00:07:22 欧拉拉呼呼
00:10:57 就像白痴一样
00:16:33 七天
00:22:12 你是我的水
00:29:00 只有夜来香
00:33:46 最寂寞的时候
00:38:44 听见了吗
00:43:56 寂寞考
00:54:32 早安晨之美
01:00:30 rock’n roll的style
01:09:42 蓝宝
01:13:50 明仔載
01:19:06 鱼仔
01:24:06 一定要相信自己
01:32:05 别在我睡着的时候打给我
01:36:47 无敌铁金刚
01:41:12 渊明
01:45:34 蚊子
01:53:34 再见勾勾
02:04:25 一个便当
02:08:20 口水流下来
02:13:04 OH YEAH!!!
02:24:42 100种生活
02:33:46 爱情怎么了吗
02:37:22 几分之几
02:42:26 清晨巴士
02:48:44 大人中
02:59:12 nice to meet you`;

test('all 29 timestamp-first album tracks, duration boundaries, exact Chinese/English names', () => {
  const tracks = parseUserTrackList(newList, 3 * 3600 + 8 * 60);
  assert.equal(tracks.length, 29);
  assert.equal(tracks[0].title, '我爱你');
  assert.deepEqual([tracks[0].start, tracks[0].end], [45, 442]);
  assert.equal(tracks[10].title, 'rock’n roll的style');
  assert.equal(tracks[10].start, 3630);
  assert.equal(tracks[22].title, 'OH YEAH!!!');
  assert.equal(tracks[23].title, '100种生活');
  assert.equal(tracks[28].title, 'nice to meet you');
  assert.deepEqual([tracks[28].start, tracks[28].end], [10752, 11280]);
  assert.equal(tracks[0].number, '01');
});

test('optional intro preserved if checked, otherwise skipped explicitly', () => {
  const skipped = parseUserTrackList(newList, 11300);
  assert.equal(skipped[0].start, 45);
  const preserved = parseUserTrackList(newList, 11300, { includeIntro: true });
  assert.equal(preserved.length, 30);
  assert.deepEqual([preserved[0].number, preserved[0].start, preserved[0].end], ['00', 0, 45]);
  assert.equal(preserved[1].number, '01');
});

test('legacy song-first list still works without spaces', () => {
  const legacy = '二零三00:00\n水乡03:47\n一程山路08:29\n小王12:05';
  const x = parseUserTrackList(legacy, 900);
  assert.equal(x.length, 4);
  assert.equal(x[1].title, '水乡');
  assert.deepEqual([x[1].start, x[1].end], [227, 509]);
});

test('mixed numbered, bracketed, delimited, milliseconds and full-width time', () => {
  const mixed = '01. [00:00] 二零三\n02) 03:47 - 水乡\n03、 一程山路 | 08:29\n04 12:05 小王\n05. １７：４６．５００ 深夜一角';
  // Full-width dot is not used in time syntax. Check common fullwidth numbers/colon with ASCII decimal point.
  const x = parseUserTrackList(mixed, 1200);
  assert.equal(x.length, 5);
  assert.equal(x[4].start, 1066.5);
  assert.equal(x[4].title, '深夜一角');
});

test('time at start or end including exact zero-width boundary and date-like numerals in titles', () => {
  const x = parseUserTrackList('00:00:00歌名\n02:04:25 - 一个便当\n100种生活 02:24:42\n02:59:12 | nice to meet you', 12000);
  assert.equal(x[0].title, '歌名');
  assert.equal(x[2].title, '100种生活');
  assert.equal(x[3].title, 'nice to meet you');
});

test('validate bad input rather than silently ignore', () => {
  assert.throws(() => parseUserTrackList('00:00:00 第一首\n00:00:00 第二首', 100), /时间必须晚于/);
  assert.throws(() => parseUserTrackList('01:99 不合法', 100), /秒数必须小于/);
  assert.throws(() => parseUserTrackList('00:00:00 第一首\n请帮我查歌词', 100), /第 2 行/);
  assert.throws(() => parseUserTrackList('00:00:45 第一首', 40), /已达到或超过/);
  assert.throws(() => parseUserTrackList('00:00:00 ', 300), /缺少歌曲名称/);
});

test('timecode details', () => {
  assert.equal(parseUserTimecode('02:59:12'), 10752);
  assert.equal(parseUserTimecode('03:47.250'), 227.25);
  assert.equal(parseUserTimecode('01:00:30.125'), 3630.125);
  assert.equal(parseUserTimecode('０１：００：３０'), 3630);
});
