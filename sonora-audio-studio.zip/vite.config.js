import { defineConfig } from 'vite';

export default defineConfig({
  // FFmpeg's package creates a Web Worker with new URL('./worker.js', import.meta.url).
  // Keep it out of dependency pre-bundling so Vite does not look for a missing
  // optimized worker.js inside node_modules/.vite/deps.
  optimizeDeps: {
    exclude: ['@ffmpeg/ffmpeg'],
  },
  // Keep worker modules in ES format for the browser-side FFmpeg worker.
  worker: {
    format: 'es',
  },
});
