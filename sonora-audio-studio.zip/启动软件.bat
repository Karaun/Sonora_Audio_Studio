@echo off
chcp 65001 >nul
cd /d "%~dp0"
where npm >nul 2>nul
if errorlevel 1 (
  echo 未检测到 Node.js / npm。
  echo 请先安装 Node.js LTS：https://nodejs.org/
  pause
  exit /b 1
)
if not exist node_modules (
  echo 正在首次安装依赖，请稍候……
  call npm install
  if errorlevel 1 (
    echo 依赖安装失败，请检查网络连接后重试。
    pause
    exit /b 1
  )
)
if not exist "node_modules\jszip" (
  echo 正在安装专辑分轨所需组件，请稍候……
  call npm install
  if errorlevel 1 (
    echo 组件安装失败，请检查网络连接后重试。
    pause
    exit /b 1
  )
)
if exist "node_modules\.vite" (
  echo 正在清理旧的 Vite 依赖缓存……
  rmdir /s /q "node_modules\.vite"
)
echo 正在启动 Sonora Audio Studio 蓝白专业版……
echo FFmpeg Worker 已设置为跳过依赖预构建。
echo 启动后请在浏览器打开 http://127.0.0.1:5173/
call npm run dev -- --force
pause
